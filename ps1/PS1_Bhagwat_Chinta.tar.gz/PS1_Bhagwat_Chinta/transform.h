int transform_function(int, int top);

void RECEIVE(int* ,
        unsigned int const, 
        unsigned int const);

void SEND(int* ,
        unsigned int const, 
        unsigned int const);
